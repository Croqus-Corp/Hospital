/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author wisdom
 */
class User {
    private String name,surname,ID,age,gender,cell,address,MedicalAidNo,MembershipNo,NameofMedical,TypeofMedical;
    
    public User(String name,String surname,String ID,String age,String gender,String cell,String address,String MedicalAidNo,String MembershipNo,String NameofMedical,String TypeofMedical){
        this.name = name;
        this.surname = surname;
        this.ID = ID;
        this.age = age;
        this.gender = gender;
        this.cell = cell;
        this.address = address;
        this.MedicalAidNo = MedicalAidNo;
        this.MembershipNo = MembershipNo;
        this.NameofMedical = NameofMedical;
        this.TypeofMedical = TypeofMedical;
    }
    public String getName(){
        return name;
    }
    public String getSurname(){
        return surname;
    }
    public String getID(){
        return ID;
    }
    public String getAge(){
        return age;
    }
    public String getGender(){
        return gender;
    }
    public String getCell(){
        return cell;
    }
    public String getAddress(){
        return address;
    }
    public String getMedicalAidNo(){
        return MedicalAidNo;
    }
    public String getMembershipNo(){
        return MembershipNo;
    }
    public String getNameofMedical(){
        return NameofMedical;
    }
    public String getTypeofMedical(){
        return TypeofMedical;
    }
    
}
